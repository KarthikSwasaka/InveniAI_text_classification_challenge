import pickle

import pika
import psycopg2
from flask import Flask, request, jsonify

app = Flask(__name__)


def get_db_connection():
    conn = psycopg2.connect(host='host.docker.internal',
                            database='mydb',
                            user='postgres',
                            password='postgres')
    return conn


clf = pickle.load(open('clf.pkl', 'rb'))


@app.route("/prediction", methods=["POST"])
def prediction():
    print('input request --> {}', request.get_json())
    # Get the input text from the request
    input_data = request.json['input']
    loaded_vec = pickle.load(open('count_vect.pkl', 'rb'))
    text_vectorized = loaded_vec.transform([input_data])
    # Make a prediction using the model
    pd = clf.predict(text_vectorized)
    # Return the prediction as JSON
    return jsonify({'prediction': str(pd[0])})


def prediction_from_message_queue(message):
    loaded_vec = pickle.load(open('count_vect.pkl', 'rb'))
    text_vectorized = loaded_vec.transform([message])
    # Make a prediction using the model
    pd = clf.predict(text_vectorized)
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO result (input, classification_value) VALUES ( %s, %s)",
                (message.decode('ascii'), str(pd[0])))
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'prediction': str(pd[0])})


@app.route("/publish-message-to-rabbitMQ", methods=["POST"])
def publish():
    print('input request --> {}', request.get_json())
    publish_message(request.json['message'])
    return jsonify({'prediction': "published successfully"})


@app.route("/subscribe-message")
def subscriber():
    subscriber_message()
    return jsonify({"result": "subscribed successfully"})


def publish_message(message):
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='host.docker.internal'))
    channel = connection.channel()
    channel.queue_declare(queue='task_queue', durable=True)
    channel.basic_publish(
        exchange='pubsub',
        routing_key='task_queue',
        body=message,
        properties=pika.BasicProperties(
            delivery_mode=2,  # make message persistent
        ))
    connection.close()


def subscriber_message():
    connection_parameters = pika.ConnectionParameters('host.docker.internal')
    connection = pika.BlockingConnection(connection_parameters)
    channel = connection.channel()
    channel.exchange_declare(exchange='pubsub', exchange_type='fanout')
    queue = channel.queue_declare(queue='', exclusive=True)
    channel.queue_bind(exchange='pubsub', queue=queue.method.queue)
    channel.basic_consume(queue=queue.method.queue, auto_ack=True,
                          on_message_callback=on_message_received)
    print("Starting Consuming")
    channel.start_consuming()
    return 'success'


def on_message_received(ch, method, properties, body):
    response = prediction_from_message_queue(body)
    print(f"firstconsumer - received new message: {response}")


@app.route('/')
def index():
    return 'OK'


if __name__ == "__main__":
    HOST = '0.0.0.0'
    PORT = 9000
    app.run(HOST, PORT, debug=True)
